declare module skins{
	class ButtonSkin extends eui.Skin{
	}
}
declare module skins{
	class CheckBoxSkin extends eui.Skin{
	}
}
declare module skins{
	class HScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class HSliderSkin extends eui.Skin{
	}
}
declare module skins{
	class ItemRendererSkin extends eui.Skin{
	}
}
declare module skins{
	class PanelSkin extends eui.Skin{
	}
}
declare module skins{
	class ProgressBarSkin extends eui.Skin{
	}
}
declare module skins{
	class RadioButtonSkin extends eui.Skin{
	}
}
declare module skins{
	class ScrollerSkin extends eui.Skin{
	}
}
declare module skins{
	class TextInputSkin extends eui.Skin{
	}
}
declare module skins{
	class ToggleSwitchSkin extends eui.Skin{
	}
}
declare module skins{
	class VScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class VSliderSkin extends eui.Skin{
	}
}
declare class DepotSceneSkin extends eui.Skin{
}
declare class shangdian_qchSkin extends eui.Skin{
}
declare class MainSceneSkin extends eui.Skin{
}
declare class AirSkin extends eui.Skin{
}
declare class AllSkin extends eui.Skin{
}
declare class apple extends eui.Skin{
}
declare class banana extends eui.Skin{
}
declare class button_cancelSkin extends eui.Skin{
}
declare class button_enterSkin extends eui.Skin{
}
declare class button_returnSkin extends eui.Skin{
}
declare class button_runSkin extends eui.Skin{
}
declare class button_shuxingSkin extends eui.Skin{
}
declare class card_list extends eui.Skin{
}
declare class card_qch extends eui.Skin{
}
declare class chilun extends eui.Skin{
}
declare class ditanliangs extends eui.Skin{
}
declare class item_allSkin extends eui.Skin{
}
declare class list_itemSkin extends eui.Skin{
}
declare class mbtnAbout extends eui.Skin{
}
declare class mbtnfactory extends eui.Skin{
}
declare class mbtnFriends extends eui.Skin{
}
declare class mbtnInsubway extends eui.Skin{
}
declare class mbtnLock extends eui.Skin{
}
declare class mbtnMessage extends eui.Skin{
}
declare class mbtnstage extends eui.Skin{
}
declare class mbtnStrategy extends eui.Skin{
}
declare class mbtntask extends eui.Skin{
}
declare class queding_qch extends eui.Skin{
}
declare class quxiao_qch extends eui.Skin{
}
declare class RunningSkin extends eui.Skin{
}
declare class Scr_skinSkin extends eui.Skin{
}
declare class subway_list extends eui.Skin{
}
declare class subway_qch extends eui.Skin{
}
declare class yilaguan extends eui.Skin{
}
declare class zhi extends eui.Skin{
}
